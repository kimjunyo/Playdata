package com.miracle.memberservice.controller;

import com.miracle.memberservice.dto.response.CompanyJoinDto;
import com.miracle.memberservice.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/company")
public class CompanyController {
    private final CompanyService companyService;

    @Autowired
    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    @GetMapping("/join-page")
    public String joinPage() {
        return "company/join-page";
    }

    @PostMapping("/join")
    public CompanyJoinDto joinUser(@Valid @RequestBody CompanyJoinDto companyJoinDto) {
        return companyService.saveCompany(companyJoinDto);
    }
}
