package com.miracle.memberservice.dto;

import com.miracle.memberservice.util.BaseApi;
import com.miracle.memberservice.util.Telephone;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.http.ResponseEntity;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Getter
@NoArgsConstructor
public class UserJoinDto extends BaseApi {

    @Email
    @NotBlank
    private String email;

    @Size(min = 6)
    @NotBlank
    private String password;

    @NotBlank
    private String name;

    @Telephone
    @NotBlank
    private String phone;

    @NotNull
    private LocalDate birth;

    @NotNull
    private Long addressId;

    private boolean authentication;

    @Builder
    public UserJoinDto(int status, String code, String message, String exception, String microsService, String email, String password, String name, String phone, LocalDate birth, Long addressId, boolean authentication) {
        super(status, code, message, exception, microsService);
        this.email = email;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.birth = birth;
        this.addressId = addressId;
        this.authentication = authentication;
    }

}
