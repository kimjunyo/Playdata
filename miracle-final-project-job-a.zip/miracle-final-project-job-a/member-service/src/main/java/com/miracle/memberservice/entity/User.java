package com.miracle.memberservice.entity;

import com.miracle.memberservice.dto.response.UserJoinDto;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String email;

    @Column(nullable = false)
    private int password;

    @Column(nullable = false, length = 30)
    private String name;

    @Column(nullable = false, length = 20)
    private String phone;

    @Column(nullable = false)
    private LocalDate birth;

    @Column(nullable = false)
    private Long addressId;

    @ElementCollection
    @CollectionTable(
            name = "user_stack",
            joinColumns = @JoinColumn(name = "user_id")
    )
    @Column(name = "stack_id", nullable = false)
    private Set<Long> stackIdSet = new HashSet<>();

    public User(UserJoinDto userJoinDto) {
        this.email = userJoinDto.getEmail();
        this.password = userJoinDto.getPassword().hashCode();
        this.name = userJoinDto.getName();
        this.phone = userJoinDto.getPhone();
        this.birth = userJoinDto.getBirth();
        this.addressId = userJoinDto.getAddressId();
    }
}
