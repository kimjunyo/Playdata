package com.miracle.memberservice.exception;

public class NoAuthenticationException extends IllegalStateException {
    public NoAuthenticationException(String message) {
        super(message);
    }
}
