package com.miracle.memberservice.util;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class BaseApi {

    private int status;
    private String code;
    private String message;
    private String exception;
    private String microsService;

    public BaseApi(int status, String code, String message, String exception, String microsService) {
        this.status = status;
        this.code = code;
        this.message = message;
        this.exception = exception;
        this.microsService = microsService;
    }
}
