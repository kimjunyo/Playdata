package com.miracle.memberservice.service;

import com.miracle.memberservice.dto.response.CompanyJoinDto;
import com.miracle.memberservice.dto.response.UserJoinDto;
import com.miracle.memberservice.entity.Company;
import com.miracle.memberservice.entity.User;
import com.miracle.memberservice.exception.NoArgsBusinessNumberException;
import com.miracle.memberservice.exception.NoAuthenticationException;
import com.miracle.memberservice.repository.CompanyRepository;
import com.miracle.memberservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CompanyService {

    private final CompanyRepository companyRepository;

    @Autowired
    public CompanyService(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    public CompanyJoinDto saveCompany(CompanyJoinDto companyJoinDto) {
        try {
            if (!companyJoinDto.isAuthentication()) {
                throw new NoAuthenticationException("인증 확인하지 않았습니다");
            }
            if (!companyJoinDto.isBusinessNumberCheck()) {
                throw new NoArgsBusinessNumberException("사업자 번호가 기입되지 않았습니다");
            }
            companyRepository.save(new Company(companyJoinDto));
            return CompanyJoinDto.builder()
                    .status(200)
                    .code("200")
                    .message("회원가입 성공")
                    .microsService("member-service")
                    .build();
        } catch (NoAuthenticationException e) {
            return CompanyJoinDto.builder()
                    .status(400)
                    .code("400_2")
                    .message("인증 확인하지 않았습니다")
                    .exception("NoAuthenticationException")
                    .microsService("member-service")
                    .build();
        } catch (NoArgsBusinessNumberException e) {
            return CompanyJoinDto.builder()
                    .status(400)
                    .code("400_3")
                    .message("사업자 번호가 기입되지 않았습니다")
                    .exception("NoArgsBusinessNumberException")
                    .microsService("member-service")
                    .build();
        } catch (RuntimeException e) {
            return CompanyJoinDto.builder()
                    .status(500)
                    .code("500")
                    .message("알 수 없는 오류입니다.")
                    .microsService("member-service")
                    .build();
        }
    }
}
