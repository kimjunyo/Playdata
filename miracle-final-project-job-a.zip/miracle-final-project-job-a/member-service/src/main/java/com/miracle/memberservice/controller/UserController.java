package com.miracle.memberservice.controller;

import com.miracle.memberservice.dto.UserJoinDto;
import com.miracle.memberservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/join-page")
    public String joinPage() {
        return "join-page";
    }

    @PostMapping("/join")
    public UserJoinDto joinUser(@Valid @RequestBody UserJoinDto userJoinDto) {
        return userService.saveUser(userJoinDto);
    }
}
