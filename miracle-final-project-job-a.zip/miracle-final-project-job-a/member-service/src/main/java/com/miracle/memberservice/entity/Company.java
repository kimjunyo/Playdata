package com.miracle.memberservice.entity;

import com.miracle.memberservice.dto.response.CompanyJoinDto;
import com.miracle.memberservice.service.CompanyService;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@DynamicInsert
@Getter
@NoArgsConstructor
@Entity
public class Company extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String email;

    @Column(nullable = false, unique = true, length = 50)
    private String bno;

    @Column(nullable = false)
    private int password;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(nullable = false, length = 50)
    private String photo;

    @Column(nullable = false, length = 30)
    private String ceoName;

    @Column(nullable = false, length = 50)
    private String sector;

    @Column(nullable = false)
    private Long addressId;

    @Column(nullable = false, length = 100)
    private String addressDetail;

    @Column(columnDefinition = "TEXT")
    private String introduction;

    @OneToMany
    @JoinColumn(name = "company_id")
    private List<CompanyFaq> faqList = new ArrayList<>();

    private int employeeNum;
    private boolean approveStatus;

    public Company(CompanyJoinDto companyJoinDto) {
        this.email = companyJoinDto.getEmail();
        this.bno = companyJoinDto.getBno();
        this.password = companyJoinDto.getPassword().hashCode();
        this.name = companyJoinDto.getName();
        this.photo = companyJoinDto.getPhoto();
        this.ceoName = companyJoinDto.getCeoName();
        this.sector = companyJoinDto.getSector();
        this.addressId = companyJoinDto.getAddressId();
        this.addressDetail = companyJoinDto.getAddressDetail();
        this.introduction = companyJoinDto.getIntroduction();
        this.employeeNum = companyJoinDto.getEmployeeNum();
        this.approveStatus = false;
    }
}
