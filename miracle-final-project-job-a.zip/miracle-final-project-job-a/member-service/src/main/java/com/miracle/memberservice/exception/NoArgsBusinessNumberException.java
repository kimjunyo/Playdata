package com.miracle.memberservice.exception;

public class NoArgsBusinessNumberException extends IllegalStateException {
    public NoArgsBusinessNumberException(String message) {
        super(message);
    }
}
