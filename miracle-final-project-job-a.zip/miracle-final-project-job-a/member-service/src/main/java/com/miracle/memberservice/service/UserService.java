package com.miracle.memberservice.service;

import com.miracle.memberservice.dto.response.UserJoinDto;
import com.miracle.memberservice.entity.User;
import com.miracle.memberservice.exception.NoAuthenticationException;
import com.miracle.memberservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserJoinDto saveUser(UserJoinDto userJoinDto) {
        try {
            if (!userJoinDto.isAuthentication()) {
                throw new NoAuthenticationException("인증 확인하지 않았습니다");
            }
            userRepository.save(new User(userJoinDto));
            return UserJoinDto.builder()
                    .status(200)
                    .code("200")
                    .message("회원가입 성공")
                    .microsService("member-service")
                    .build();
        } catch (NoAuthenticationException e) {
            return UserJoinDto.builder()
                    .status(400)
                    .code("400_2")
                    .message("인증 확인하지 않았습니다")
                    .exception("NoAuthenticationException")
                    .microsService("member-service")
                    .build();
        } catch (RuntimeException e) {
            return UserJoinDto.builder()
                    .status(500)
                    .code("500")
                    .message("알 수 없는 오류입니다.")
                    .microsService("member-service")
                    .build();
        }
    }
}
