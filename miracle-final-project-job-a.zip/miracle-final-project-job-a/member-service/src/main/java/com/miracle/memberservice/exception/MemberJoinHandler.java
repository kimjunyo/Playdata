package com.miracle.memberservice.exception;

import com.miracle.memberservice.dto.response.UserJoinDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Slf4j
public class MemberJoinHandler {

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public UserJoinDto notValidMemberInfo(MethodArgumentNotValidException manve) {
        log.info("notValidMemberInfo Exception 터짐");
        return UserJoinDto.builder()
                .status(400)
                .code("400_1")
                .message("회원정보 형식이 맞지 않거나 존재하지 않습니다.")
                .exception("notValidMemberInfo")
                .microsService("member-service")
                .build();
    }
}
