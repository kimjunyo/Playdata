package com.miracle.memberservice.dto.response;

import com.miracle.memberservice.entity.CompanyFaq;
import com.miracle.memberservice.util.BaseApi;
import com.miracle.memberservice.util.Telephone;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;

@Getter
@NoArgsConstructor
public class CompanyJoinDto extends BaseApi {

    @Email
    @NotBlank
    private String email;

    @NotBlank
    private String bno;

    @Size(min = 6)
    @NotBlank
    private String password;

    @NotBlank
    private String name;

    @NotBlank
    private String photo;

    @NotNull
    private String ceoName;

    @NotNull
    private String sector;

    @NotNull
    private Long addressId;

    @NotNull
    private String addressDetail;

    private String introduction;

    private int employeeNum;

    private boolean authentication;
    private boolean businessNumberCheck;

    @Builder
    public CompanyJoinDto(int status, String code, String message, String exception, String microsService, String email, String bno, String password, String name, String photo, String ceoName, String sector, Long addressId, String addressDetail, String introduction, int employeeNum, boolean authentication, boolean businessNumberCheck) {
        super(status, code, message, exception, microsService);
        this.email = email;
        this.bno = bno;
        this.password = password;
        this.name = name;
        this.photo = photo;
        this.ceoName = ceoName;
        this.sector = sector;
        this.addressId = addressId;
        this.addressDetail = addressDetail;
        this.introduction = introduction;
        this.employeeNum = employeeNum;
        this.authentication = authentication;
        this.businessNumberCheck = businessNumberCheck;
    }
}
